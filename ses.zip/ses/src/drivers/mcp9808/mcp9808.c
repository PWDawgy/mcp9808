#include "mcp9808.h"
#include <stdio.h>    

// Static variable to hold the injected I2C interface
static I2C_Interface* i2cInterface = NULL;


bool MCP9808_Init(void) {
    return true;
}
