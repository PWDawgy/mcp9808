#include <stdio.h>
#include "drivers/mcp9808/mcp9808.h"

int main()
{
    return MCP9808_Init();
    
}